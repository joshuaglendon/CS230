import { Component } from "@angular/core";

@Component({
    selector: 'app-bottom-nav-bar',
    templateUrl: 'bottom-nav-bar.component.html',
})
export class BottomNavBarComponent {
    
}